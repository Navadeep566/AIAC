# 📘 CSV Data Cleaner – AIAC Course Project

## 🔹 Project Overview

The **CSV Data Cleaner** is a smart data-processing tool that automatically cleans messy CSV files.
It uses advanced logic to detect and fix:

- Invalid or inconsistent dates
- Misformatted numeric values
- Word-numbers (e.g., “thirty five” → 35)
- Currency symbols, commas, and mixed units
- Empty or missing cells
- Duplicate rows
- Category spelling mistakes (via fuzzy matching)
- Outlier numeric values
- Irregular text formatting (spacing, quotes, capitalization)

The project includes:
✔ A **Python backend script (`cleaner.py`)** for transforming CSV files
✔ A **simple professional UI (`index.html`)** for uploading and cleaning CSVs in the browser
✔ Support for any random CSV structure—columns are auto-detected and cleaned accordingly

---

## 👥 Team Members

| Name                   | Roll Number |
| ---------------------- | ----------- |
| **Navadeep Munugoti**  | 2403A52015  |
| **Vamshi Vadlakonda**  | 2403A52016  |
| **Sai Amrutha Gurram** | 2403A52017  |

---

## 🎯 Objectives

The purpose of this project is to design a **universal automatic CSV cleaning system** that:

- Detects column types intelligently (date, number, category, text)
- Cleans data consistently without manual intervention
- Provides a summary of all fixes applied
- Exports clean, analysis-ready CSV files
- Works both **offline** and **directly inside the browser**

---

## 🧠 Features of the Data Cleaner

### 🔍 Auto Column Type Detection

Identifies column type using heuristics & sampling:

- Date columns
- Numeric columns
- Category columns
- Free-text columns

### 🛠 Cleaning Operations

| Type             | Fixes Applied                                                               |
| ---------------- | --------------------------------------------------------------------------- |
| **Date**         | Converts all formats into `YYYY-MM-DD`, sets invalid as `null`              |
| **Number**       | Converts word-numbers, removes currency, fixes decimals, handles k/m suffix |
| **Category**     | Uses fuzzy matching to correct typos (e.g., "Actve" → "Active")             |
| **Text**         | Removes quotes, trims spaces, converts to title case                        |
| **Outliers**     | Detects with Z-score and replaces extreme values with `null`                |
| **Duplicates**   | Removes exact duplicate rows                                                |
| **Empty Values** | Converts all blank/NA/None/N/A to `null`                                    |

### 📊 Cleaning Summary Generated

After cleaning, the script displays:

- Dates fixed
- Numbers fixed
- Empty cells replaced
- Outliers removed
- Category corrections
- Duplicate rows removed
- Total corrected cells

### 💾 Output

A fully cleaned CSV saved to:

```
data_cleaner/sample_output/cleaned_output.csv
```

---

## 🗂 Project Structure

```
AIAC_COURSE_PROJECT/
│
├── data_cleaner/
│   ├── sample_input/
│   │     └── sample.csv
│   ├── sample_output/
│   │     └── cleaned_output.csv
│   └── source_code/
│          └── cleaner.py
│
├── index.html    → Web UI
└── README.md     → Project documentation
```

---

## ▶️ How to Run the Project

### **Option 1 – Run Cleaning Through Python (Backend Mode)**

1. Open VS Code
2. Open Terminal → Navigate to source code folder:

```
cd data_cleaner/source_code
```

3. Run:

```
py cleaner.py ../sample_input/sample.csv ../sample_output/cleaned_output.csv
```

4. Output will appear in the `sample_output` folder.

---

### **Option 2 – Run Through the Web UI (Frontend Mode)**

1. Open `index.html` in any browser
2. Upload a CSV file
3. Click **Clean CSV**
4. View cleaned data instantly
5. Download the processed CSV

> The web version works **entirely offline** — no server needed.

---

## 📦 Required Libraries

The Python script uses the following modules:

```
pandas
numpy
word2number
rapidfuzz
re (builtin)
datetime (builtin)
```

Install dependencies using:

```
py -m pip install pandas numpy word2number rapidfuzz
```

---

## 📝 Sample Input & Output

### **Example Input Row**

| name | age    | salary    | city     | join_date |
| ---- | ------ | --------- | -------- | --------- |
| bob  | thirty | 60,000 Rs | Warangal | 05-12-23  |

### **Output After Cleaning**

| name | age | salary | city     | join_date  |
| ---- | --- | ------ | -------- | ---------- |
| Bob  | 30  | 60000  | Warangal | 2023-12-05 |

---

## 📚 Applications of This Project

- Preprocessing datasets for machine learning
- Cleaning academic/student datasets
- Financial CSV reconciliation
- Data preparation for analysis dashboards
- Data correction for administrative systems

---

## 🚀 Future Enhancements

- Detect semantic types (email, phone, ID numbers)
- ML-based automatic type detection
- Web UI with chart-based anomaly visualization
- Auto-merge partially duplicated rows
