import pandas as pd
import re
from datetime import datetime
from word2number import w2n

# =======================================================
#              TYPE DETECTION HELPERS
# =======================================================

def detect_column_type(series):
    """
    Auto-detects if a column is:
    - date
    - number
    - text
    """
    values = series.dropna().astype(str)
    if len(values) == 0:
        return "text"

    date_count = 0
    number_count = 0

    for v in values:
        if looks_like_date(v):
            date_count += 1
        if looks_like_number(v):
            number_count += 1

    if date_count > len(values) * 0.40:
        return "date"
    if number_count > len(values) * 0.40:
        return "number"
    return "text"


# =======================================================
#                DATE DETECTION + CLEANING
# =======================================================

DATE_FORMATS = [
    "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%m-%d-%Y",
    "%b %d %Y", "%d %b %Y", "%b %d, %Y",
    "%d-%b-%Y", "%Y%m%d", "%d-%m-%y"
]

def looks_like_date(value):
    value = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            datetime.strptime(value, fmt)
            return True
        except:
            continue
    return False


def clean_date(value):
    if pd.isna(value):
        return "null"

    value = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d")
        except:
            continue

    # if cannot fix → mark as null
    return "null"


# =======================================================
#             NUMBER DETECTION + CLEANING
# =======================================================

def looks_like_number(value):
    if pd.isna(value):
        return False

    value = str(value).lower().strip()

    # Pure numbers or decimals
    if re.match(r"^[\d\.,]+$", value):
        return True

    # Contains units / currency
    if re.match(r"^[\d\.,]+\s?(rs|usd|inr|k|m)$", value):
        return True

    # Word numbers ("thirty five")
    try:
        w2n.word_to_num(value)
        return True
    except:
        return False


def clean_number(value):
    if pd.isna(value):
        return "null"
    v = str(value).lower().strip()

    # Word numbers (example: "thirty")
    try:
        return str(w2n.word_to_num(v))
    except:
        pass

    # Remove non-number characters
    v = re.sub(r"[^0-9.]", "", v)
    if v == "":
        return "null"

    # Fix decimal issues like "12..3"
    if v.count(".") > 1:
        v = v.replace(".", "", v.count(".") - 1)

    return v


# =======================================================
#                 TEXT CLEANING
# =======================================================

def clean_text(value):
    if pd.isna(value) or str(value).strip() == "":
        return "null"

    v = str(value).strip()

    # Remove abnormal characters
    v = re.sub(r"[^A-Za-z0-9\s\.-]", "", v)

    # Normalize spaces
    v = re.sub(r"\s+", " ", v).strip()

    # Convert known null indicators
    if v.lower() in ["na", "none", "null", "nan"]:
        return "null"

    return v.title()


# =======================================================
#          MAIN UNIVERSAL CLEAN FUNCTION
# =======================================================

def clean_csv(input_file, output_file):
    df = pd.read_csv(input_file)

    stats = {
        "dates_fixed": 0,
        "numbers_fixed": 0,
        "text_fixed": 0,
        "empty_replaced": 0,
        "duplicates_removed": 0,
    }

    corrected_cells = []

    # AUTO DETECT COLUMN TYPES
    col_types = {}
    for col in df.columns:
        col_types[col] = detect_column_type(df[col])

    # CLEAN COLUMN BASED ON TYPE
    for col in df.columns:
        for i, val in df[col].items():
            old = val

            if col_types[col] == "date":
                new = clean_date(val)
                if new != old:
                    stats["dates_fixed"] += 1

            elif col_types[col] == "number":
                new = clean_number(val)
                if new != old:
                    stats["numbers_fixed"] += 1

            else:
                new = clean_text(val)
                if new != old:
                    stats["text_fixed"] += 1

            if new == "" or pd.isna(new):
                new = "null"
                stats["empty_replaced"] += 1

            if new != old:
                corrected_cells.append((i, col))

            df.at[i, col] = new

    # REMOVE DUPLICATES
    before = len(df)
    df.drop_duplicates(inplace=True)
    stats["duplicates_removed"] = before - len(df)

    # SAVE OUTPUT
    df.to_csv(output_file, index=False)

    print("\n===== CLEANING DONE =====")
    print(f"Dates fixed: {stats['dates_fixed']}")
    print(f"Numbers fixed: {stats['numbers_fixed']}")
    print(f"Text fixed: {stats['text_fixed']}")
    print(f"Empty cells replaced: {stats['empty_replaced']}")
    print(f"Duplicate rows removed: {stats['duplicates_removed']}")
    print(f"Saved cleaned file: {output_file}")

    return stats, corrected_cells
